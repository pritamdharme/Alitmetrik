package RestAssuradTest;

import org.testng.annotations.Test;

import groovy.util.logging.Log;

import static org.hamcrest.Matcher.*;
import static io.restassured.RestAssured.*;

import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.CoreMatchers.equalTo;

import org.apache.http.client.methods.HttpGet;
import org.hamcrest.Matcher;
import org.hamcrest.collection.HasItemInArray;
import org.json.JSONArray;

import static org.hamcrest.CoreMatchers.containsString;
import io.restassured.http.ContentType;
import java.util.HashMap;
import java.util.List;


/*
Beginner Requirements:

1.     Manage dependencies between API calls.

2.     Verify the response status code.

3.     Verify the response contents (Minimum 2)

4. Read request body from a file and Serialize into a POJO.


5.Extract values from Response and display them.

*/


public class PostEcho{
	
	final static String ROOT_URI = "https://postman-echo.com";
	public HashMap map=new HashMap();
	public static String jsonAsString;
	public static Response response;
	@Test(priority = 1,description = "Get Resquest demo")
	public void Getdata()
	{
		given().params("foo1", "bar1","foo2","bar2")//optional
		.headers("set-cookie","sails.sid=s%3AGz-wblZgXE8FCDq7aJpx_tUgZUcG3Nsw.LdNEN8L0C7nGWkvGLwvdw6R2s6Syjr%2FzkvyevA8qR0c; Path=/; HttpOnly","Content-Type","application/json; charset=utf-8")
		.when()
		.get(ROOT_URI+"/get?foo1=bar1&foo2=bar2")
		.then()
		.statusCode(200)
		.body("args.foo1",equalTo("bar1")).and().body("args.foo2", equalTo("bar2"))
		.body("headers.x-forwarded-port",equalTo("443"))
		//Verified  the response contents (Minimum 2)
		.log().all();
	  
	
	}
	
	@Test(priority=2,description = "Post  Resquest  by raw data") 	
	public void postrawdata()
	{
		given().contentType("application/json")
		.body("This is expected to be sent back as part of response body")
		.when()
		.post(ROOT_URI+"/post")
		.then()
		.statusCode(200)
		.log().all()
		.assertThat().body(containsString("This is expected to be sent back as part of response body"));
		

   }
	
  @Test(priority=3,description = "Post  Resquest  by form data")
  public void postformdata()
	{    
	     given().contentType("application/x-www-form-urlencoded; charset=UTF-8")
	     .formParam("foo1", "bar1")
	     .formParam("foo2", "bar2")
		.when()
		.post(ROOT_URI+"/post")
		.then()
		.statusCode(200)
		 .body("json.foo1",equalTo("bar1")).and().body("json.foo2", equalTo("bar2"));	
 }
  
  
  @Test(priority=4,description = "Put Resquest")
  public void putdata()
	{    
	     given().given().contentType("application/json")
			.body("This is expected to be sent back as part of response body")
		.when()
		.put(ROOT_URI+"/put")
		.then()
		.statusCode(200)
		.assertThat().body(containsString("This is expected to be sent back as part of response body"));
 }
  
  @Test(priority=5,description = "delete Resquest")
  public void deletedata()
	{    
	     given().given().contentType("application/json")
			.body("This is expected to be sent back as part of response body")
		.when()
		.delete(ROOT_URI+"/delete")
		.then()
		.statusCode(200)
		.assertThat().body(containsString("This is expected to be sent back as part of response body"));
 }
  
  
  @Test(priority=5, description ="Read request body from a file and Serialize into a POJO and Extract values from Response and displayed them")
  public void serilizationdata()
	{    
	    test t=new test(); 
	    t.setFoo1("bar1");
	    t.setFoo2("bar2");
	    response=
	    given().contentType(ContentType.JSON)
		.body(t)
	  .when()
	  .post(ROOT_URI+"/post")
	 .then()
	 .statusCode(200)
	.log().all()
	.body("json.foo1",equalTo("bar1")).and().body("json.foo2", equalTo("bar2"))
	.extract().response().prettyPeek();
	    	}   

}

  
  
	
